AMS Lectures — Test Website
================================

This is a static, deploy-ready site for Stripe verification and functional "Buy Now" buttons.

WHAT'S INCLUDED
---------------
- index.html with a modern hero, two course cards (PM & TX), and a currency selector.
- Each "Buy Now" button routes to a Stripe Payment Link based on the selected currency.
- Placeholders are included for Payment Links — replace them before going live.

HOW TO CREATE STRIPE PAYMENT LINKS
----------------------------------
1) In Stripe Dashboard, go to: Payments > Payment links > Create payment link.
2) Create ONE product for each course (PM and TX), with prices for PKR, GBP, EUR, USD.
   - Or create separate links per currency if you prefer.
3) After creating each link, copy the URL (looks like https://buy.stripe.com/...) and replace the placeholders in index.html:

   PM:
     REPLACE_PM_PKR_PAYMENT_LINK
     REPLACE_PM_GBP_PAYMENT_LINK
     REPLACE_PM_EUR_PAYMENT_LINK
     REPLACE_PM_USD_PAYMENT_LINK

   TX:
     REPLACE_TX_PKR_PAYMENT_LINK
     REPLACE_TX_GBP_PAYMENT_LINK
     REPLACE_TX_EUR_PAYMENT_LINK
     REPLACE_TX_USD_PAYMENT_LINK

TIP: If your Stripe Product supports multiple currencies in a single Payment Link, you can paste the same link in all four spots.

HOW TO DEPLOY ON VERCEL (GITHUB METHOD)
---------------------------------------
1) Create a repo named `amslectures` on GitHub.
2) Upload index.html to the repo (root folder).
3) In Vercel, click "New Project" > Import Git Repository > select `amslectures` > Deploy.
4) You'll get a link like https://amslectures.vercel.app — paste that into Stripe.

NO SECRETS IN FRONTEND
----------------------
Do NOT put your Stripe SECRET key in index.html. Payment Links let you charge securely without exposing secrets.

NEED CHANGES?
-------------
- Swap text, colours, or add sections easily within index.html.
- For native DRM video streaming and library pages, you'll need a Next.js app + Mux/DRM backend (I can build that when you're ready).
